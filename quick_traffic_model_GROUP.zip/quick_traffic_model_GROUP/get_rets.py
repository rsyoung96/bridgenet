# By: Gitanjali Bhattacharjee
# last modified: 5 June 2018
# ----------------------------------------------------------------------------------------------------------------------
# This script imports the original master_dict that contains the fragility function parameters of every bridge in the
# Bay Area that is owned by CalTrans. It then copies that dictionary and updates the fragility function parameters of
# bridges that undergo retrofit. That update is simply an increase in the median of each fragility function, which
# results in the curve shifting to the right, in graphical terms.

# user inputs:
# - retrofit improvement factor: reflects percent increase in median of each fragility function (type: float)
# - bridges to retrofit: list of the new IDs of bridges (between 1 and 1743, inclusive) to retrofit (type: list of strings)
# outputs:
# - master_dict_ret: dictionary with the same structure and key-value pairs of master_dict, but with updated fragility
# function parameters (type: dictionary)

import pickle, copy, csv

# placeholder - retrofit improvement factor (user-defined)
ret_factor = 1.15 # DO NOT CHANGE
assert ret_factor > 1.0

# FIX THIS placeholder - get new IDs of bridges to retrofit from user-defined list
#rets = ['300','812','22','55']

# ----------------------------------------------------------------------------------------------------------------------
# for ranking-based strategies, get lists of retrofits

# for ranking by age
# with open('/Users/gitanjali/Desktop/TransportNetworks/quick_traffic_model/input/ret_old.csv', 'rb') as csvfile:
#     csv.QUOTE_ALL
#     ret_old = csv.reader(csvfile, delimiter=',')
#     next(ret_old, None)
#     ret_old_list = list(ret_old)
#
#
# ret_old_list_final = []
#
# for i in range(0,len(ret_old_list)):
#     temp = filter(None, ret_old_list[i])
#     ret_old_list_final.append(temp)
#
# del temp
#
# # get master_dict
# with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
#     master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)
#
# #print master_dict.keys()
#
# # GB: create inverse dictionary to map new IDs to original IDs
# new_to_oldIDs = {}
# for k, v in master_dict.items():
#     for v2 in v.keys():
#         if v2 == 'new_id':
#             n = master_dict[k][v2]
#             new_to_oldIDs[str(n)] = k  # key = newID, value = originalID
#
#
# # duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
# for j in range(0,len(ret_old_list_final)):
#     master_dict_ret = copy.deepcopy(master_dict)
#
#     rets_oldID = []
#     for i in range(len(ret_old_list_final[j])):
#         oldID = new_to_oldIDs[ret_old_list_final[j][i]]
#         rets_oldID.append(oldID)
#
#     print rets_oldID
#
#     for i in range(len(ret_old_list_final[j])):
#         master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor
#
#     for i in range(0,len(ret_old_list_final)):
#         filename = 'input/master_bridge_dict_ret_old_%d.pkl' % int(j)
#         with open(filename, 'wb') as f:
#             pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)
#
#     del master_dict_ret
#
# print('Got age-based retrofits.')
# ----------------------------------------------------------------------------------------------------------------------
# for ranking by daily average traffic volume
# with open('/Users/gitanjali/Desktop/TransportNetworks/quick_traffic_model/input/ret_traf.csv', 'rb') as csvfile:
#     csv.QUOTE_ALL
#     ret_traf = csv.reader(csvfile, delimiter=',')
#     next(ret_traf, None)
#     ret_traf_list = list(ret_traf)
#
#
# ret_traf_list_final = []
#
# for i in range(0,len(ret_traf_list)):
#     temp = filter(None, ret_traf_list[i])
#     ret_traf_list_final.append(temp)
#
# del temp
#
# # get master_dict
# with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
#     master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)
#
# #print master_dict.keys()
#
# # GB: create inverse dictionary to map new IDs to original IDs
# new_to_oldIDs = {}
# for k, v in master_dict.items():
#     for v2 in v.keys():
#         if v2 == 'new_id':
#             n = master_dict[k][v2]
#             new_to_oldIDs[str(n)] = k  # key = newID, value = originalID
#
#
# # duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
# for j in range(0,len(ret_traf_list_final)):
#     master_dict_ret = copy.deepcopy(master_dict)
#
#     rets_oldID = [] # old here just means original ID, not new ID
#     for i in range(len(ret_traf_list_final[j])):
#         oldID = new_to_oldIDs[ret_traf_list_final[j][i]]
#         rets_oldID.append(oldID)
#
#     print rets_oldID
#
#     for i in range(len(ret_traf_list_final[j])):
#         master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor
#
#     for i in range(0,len(ret_traf_list_final)):
#         filename = 'input/master_bridge_dict_ret_traf_%d.pkl' % int(j)
#         with open(filename, 'wb') as f:
#             pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)
#
#     del master_dict_ret
#
# print('Got traffic-based retrofits.')
# # ----------------------------------------------------------------------------------------------------------------------
# # for betweenness centrality, get retrofits
# with open('/Users/gitanjali/Desktop/TransportNetworks/quick_traffic_model/input/betweenness_centrality_lst.csv', 'rb') as csvfile:
#     csv.QUOTE_ALL
#     ret_betw = csv.reader(csvfile, delimiter=',')
#     next(ret_betw, None)
#     ret_betw_list = list(ret_betw)
#
#
# ret_betw_list_final = []
#
# for i in range(0,len(ret_betw_list)):
#     temp = filter(None, ret_betw_list[i])
#     print temp
#     for j in range(0,len(temp)):
#         temp[j] = temp[j][1:]
#     print temp
#     ret_betw_list_final.append(temp)
#
# del temp
#
# # get master_dict
# with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
#     master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)
#
# #print master_dict.keys()
#
# # GB: create inverse dictionary to map new IDs to original IDs
# new_to_oldIDs = {}
# for k, v in master_dict.items():
#     for v2 in v.keys():
#         if v2 == 'new_id':
#             n = master_dict[k][v2]
#             new_to_oldIDs[str(n)] = k  # key = newID, value = originalID
#
#
# # duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
# for j in range(0,len(ret_betw_list_final)):
#     master_dict_ret = copy.deepcopy(master_dict)
#
#     rets_oldID = [] # old here just means original ID, not new ID
#     for i in range(len(ret_betw_list_final[j])):
#         oldID = new_to_oldIDs[ret_betw_list_final[j][i]]
#         rets_oldID.append(oldID)
#
#     print rets_oldID
#
#     for i in range(len(ret_betw_list_final[j])):
#         master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor
#
#     for i in range(0,len(ret_betw_list_final)):
#         filename = 'input/master_bridge_dict_ret_betw_%d.pkl' % int(j)
#         with open(filename, 'wb') as f:
#             pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)
#
#     del master_dict_ret
#
# print('Got betweenness centrality-based retrofits.')
# ----------------------------------------------------------------------------------------------------------------------
# for local clustering, get retrofits
# with open('/Users/gitanjali/Desktop/TransportNetworks/quick_traffic_model/input/local_clustering_lst.csv', 'rb') as csvfile:
#     csv.QUOTE_ALL
#     ret_clust = csv.reader(csvfile, delimiter=',')
#     next(ret_clust, None)
#     ret_clust_list = list(ret_clust)
#
#
# ret_clust_list_final = []
#
# for i in range(0,10): #len(ret_clust_list)
#     temp = filter(None, ret_clust_list[i])
#     print temp
#     for j in range(0,len(temp)):
#         temp[j] = temp[j][1:]
#     print temp
#     ret_clust_list_final.append(temp)
#
# del temp
#
# # get master_dict
# with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
#     master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)
#
# #print master_dict.keys()
#
# # GB: create inverse dictionary to map new IDs to original IDs
# new_to_oldIDs = {}
# for k, v in master_dict.items():
#     for v2 in v.keys():
#         if v2 == 'new_id':
#             n = master_dict[k][v2]
#             new_to_oldIDs[str(n)] = k  # key = newID, value = originalID
#
#
# # duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
# for j in range(0,len(ret_clust_list_final)):
#     master_dict_ret = copy.deepcopy(master_dict)
#
#     rets_oldID = [] # old here just means original ID, not new ID
#     for i in range(len(ret_clust_list_final[j])):
#         oldID = new_to_oldIDs[ret_clust_list_final[j][i]]
#         rets_oldID.append(oldID)
#
#     print rets_oldID
#
#     for i in range(len(ret_clust_list_final[j])):
#         master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor
#
#     for i in range(0,len(ret_clust_list_final)):
#         filename = 'input/master_bridge_dict_ret_clust_%d.pkl' % int(j)
#         with open(filename, 'wb') as f:
#             pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)
#
#     del master_dict_ret
#
# print('Got local clustering coefficient-based retrofits.')
# ----------------------------------------------------------------------------------------------------------------------
# for local clustering, get retrofits
# with open('/Users/gitanjali/Desktop/TransportNetworks/quick_traffic_model/input/modularity_output.csv', 'rb') as csvfile:
#     csv.QUOTE_ALL
#     ret_highmod = csv.reader(csvfile, delimiter=',')
#     next(ret_highmod, None)
#     ret_highmod_list = list(ret_highmod)
#
#
# ret_highmod_list_final = []
#
# for i in range(0,len(ret_highmod_list)): #len(ret_clust_list)
#     temp = filter(None, ret_highmod_list[i])
#     print temp
#     for j in range(0,len(temp)):
#         temp[j] = temp[j][1:]
#     print temp
#     ret_highmod_list_final.append(temp)
#
# del temp
#
# # get master_dict
# with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
#     master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)
#
# #print master_dict.keys()
#
# # GB: create inverse dictionary to map new IDs to original IDs
# new_to_oldIDs = {}
# for k, v in master_dict.items():
#     for v2 in v.keys():
#         if v2 == 'new_id':
#             n = master_dict[k][v2]
#             new_to_oldIDs[str(n)] = k  # key = newID, value = originalID
#
#
# # duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
# for j in range(0,len(ret_highmod_list_final)):
#     master_dict_ret = copy.deepcopy(master_dict)
#
#     rets_oldID = [] # old here just means original ID, not new ID
#     for i in range(len(ret_highmod_list_final[j])):
#         oldID = new_to_oldIDs[ret_highmod_list_final[j][i]]
#         rets_oldID.append(oldID)
#
#     print rets_oldID
#
#     for i in range(len(ret_highmod_list_final[j])):
#         master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor
#
#     for i in range(0,len(ret_highmod_list_final)):
#         filename = 'input/master_bridge_dict_ret_highmod_%d.pkl' % int(j)
#         with open(filename, 'wb') as f:
#             pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)
#
#     del master_dict_ret
#
# print('Got high-modularity-based retrofits.')
# ----------------------------------------------------------------------------------------------------------------------
# TEST: retrofit every bridge in the network

# list_all = []
#
# for i in range(0,1743): #len(ret_clust_list)
#     list_all.append(i)
#
# #print list_all
# get master_dict
# with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
#     master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)
#
# #print master_dict.keys()
#
# # GB: create inverse dictionary to map new IDs to original IDs
# new_to_oldIDs = {}
# for k, v in master_dict.items():
#     for v2 in v.keys():
#         if v2 == 'new_id':
#             n = master_dict[k][v2]
#             new_to_oldIDs[str(n)] = k  # key = newID, value = originalID
#
# # duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
# for j in range(0,1):
#     master_dict_ret = copy.deepcopy(master_dict)
#
#     rets_oldID = [] # old here just means original ID, not new ID
#     for i in range(0,1743):
#         oldID = new_to_oldIDs[str(i+1)]
#         rets_oldID.append(oldID)
#
#     print len(rets_oldID)
#
#     for i in range(0,1743):
#         master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
#         master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor
#
#
#     filename = 'input/master_bridge_dict_ret_all.pkl'
#     with open(filename, 'wb') as f:
#         pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)
#
#     del master_dict_ret
#
# print('Got all-bridge retrofits.')
# # ----------------------------------------------------------------------------------------------------------------------
# for betweenness centrality UPDATED WITH WEIGHTS, get retrofits
with open('/Users/gitanjali/Desktop/TransportNetworks/quick_traffic_model/input/betweenness_centrality_lst_withweight.csv', 'rb') as csvfile: #CHANGE FILEPATH AND FILENAME
    csv.QUOTE_ALL
    ret_betw = csv.reader(csvfile, delimiter=',')
    next(ret_betw, None)
    ret_betw_list = list(ret_betw)


ret_betw_list_final = []

for i in range(0,len(ret_betw_list)):
    temp = filter(None, ret_betw_list[i])
    print temp
    for j in range(0,len(temp)):
        temp[j] = temp[j][1:]
    print temp
    ret_betw_list_final.append(temp)

del temp

# get master_dict
with open('input/20140114_master_bridge_dict.pkl', 'rb') as f:
    master_dict = pickle.load(f)  # has 1743 keys. One per highway bridge. (NOT BART)

#print master_dict.keys()

# GB: create inverse dictionary to map new IDs to original IDs
new_to_oldIDs = {}
for k, v in master_dict.items():
    for v2 in v.keys():
        if v2 == 'new_id':
            n = master_dict[k][v2]
            new_to_oldIDs[str(n)] = k  # key = newID, value = originalID


# duplicate the master_dict to  modify fragility function parameters for retrofit - DO NOT modify anything in master_dict
for j in range(0,len(ret_betw_list_final)):
    master_dict_ret = copy.deepcopy(master_dict)

    rets_oldID = [] # old here just means original ID, not new ID
    for i in range(len(ret_betw_list_final[j])):
        oldID = new_to_oldIDs[ret_betw_list_final[j][i]]
        rets_oldID.append(oldID)

    print rets_oldID

    for i in range(len(ret_betw_list_final[j])):
        master_dict_ret[rets_oldID[i]]['mod_lnSa'] = master_dict[rets_oldID[i]]['mod_lnSa']*ret_factor
        master_dict_ret[rets_oldID[i]]['ext_lnSa'] = master_dict[rets_oldID[i]]['ext_lnSa']*ret_factor
        master_dict_ret[rets_oldID[i]]['com_lnSa'] = master_dict[rets_oldID[i]]['com_lnSa']*ret_factor

    # gb note - resume at 54
    for i in range(0,len(ret_betw_list_final)):
        filename = 'input/master_bridge_dict_ret_betw_weight_%d.pkl' % int(j) #CHANGE OUTPUT FILENAME
        with open(filename, 'wb') as f:
            pickle.dump(master_dict_ret, f, protocol=pickle.HIGHEST_PROTOCOL)

    del master_dict_ret

print('Got betweenness centrality-based retrofits.') # CHANGE THIS IF YOU WANT